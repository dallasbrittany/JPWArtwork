/*
* LICENSE: https://raw.github.com/apimash/StarterKits/master/LicenseTerms-SampleApps%20.txt
*/
using Cirrious.CrossCore.Plugins;

namespace XPlatformCloudKit.Bootstrap
{
    public class FilePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.File.PluginLoader>
    {
    }
}